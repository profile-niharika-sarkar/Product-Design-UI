'use client';

import React from 'react';
import { motion } from 'motion/react';
import { Clock } from 'lucide-react';

export const ValueGaps: React.FC = () => {
  const gaps = [
    {
      step: '01',
      title: 'Opportunity → Capability',
      desc: 'The tools are available. The skills aren’t.',
    },
    {
      step: '02',
      title: 'Capability → Application',
      desc: 'They passed the training. Nothing changed on the job.',
    },
    {
      step: '03',
      title: 'Application → Performance',
      desc: 'Daily AI use, no clarity on whether work improved.',
    },
    {
      step: '04',
      title: 'Performance → Value',
      desc: 'Tasks are faster. The organization captured nothing.',
    },
  ];

  return (
    <section
      id="measurement"
      className="scroll-mt-24 bg-[#f5f8f7] py-16 sm:py-24 relative overflow-hidden border-b border-[#39918d]/25 text-[#0c2940]"
    >
      <div className="relative mx-auto max-w-[1484px] px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl"
        >
          <span className="font-[family-name:var(--font-montserrat)] text-xs font-bold uppercase tracking-[0.25em] text-[#3f6d67] bg-[#3f6d67]/10 border border-[#3f6d67]/25 px-3.5 py-1.5 rounded-full inline-block">
            MEASUREMENT: WHERE VALUE GETS LOST
          </span>
          <h2 className="mt-3 font-[family-name:var(--font-montserrat)] text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-[#0c2940]">
            Most AI training measures adoption. We measure where value gets lost.
          </h2>
          <p className="mt-4 font-[family-name:var(--font-montserrat)] font-semibold text-base sm:text-lg text-[#c57b4b]">
            Your team completed the training. They’re using the tools. So where did the value go?
          </p>
          <p className="mt-2 font-[family-name:var(--font-opensans)] text-sm sm:text-base leading-relaxed text-[#0c2940]/80">
            AI creates opportunity, but opportunity doesn’t automatically become value. Between what AI
            makes possible and what your organization captures, there are gaps. We find them.
          </p>
        </motion.div>

        {/* 4 Value Gap Cards in Light Mixed Styling */}
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4 items-stretch">
          {gaps.map((item, idx) => (
            <motion.div
              key={item.step}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              className="flex flex-col justify-between rounded-2xl border-2 border-[#39918d]/25 bg-white p-6 sm:p-7 shadow-lg shadow-[#0c2940]/5 transition-all duration-300 hover:border-[#f8c51c] hover:shadow-[0_0_25px_rgba(248,197,28,0.25)] text-[#0c2940]"
            >
              <div>
                <span className="inline-block rounded-full bg-[#c57b4b] px-3.5 py-1 font-[family-name:var(--font-montserrat)] text-xs font-bold text-white shadow-sm">
                  {item.step}
                </span>

                <h3 className="mt-4 font-[family-name:var(--font-montserrat)] font-medium text-base sm:text-lg text-[#0c2940]">
                  {item.title}
                </h3>

                <p className="mt-2 font-[family-name:var(--font-opensans)] text-sm sm:text-[15px] leading-relaxed text-[#0c2940]/75">
                  {item.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* The Missing 30 Minutes Focal Luxury Container in Navy & Gold */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.55, delay: 0.2 }}
          className="mt-10 rounded-2xl border-2 border-[#f8c51c] bg-[#0c2940] p-6 sm:p-8 md:p-10 relative overflow-hidden shadow-2xl text-white"
        >
          <div className="pb-4 border-b border-[#f8c51c]/30">
            <h3 className="font-[family-name:var(--font-montserrat)] font-medium text-xl sm:text-2xl text-[#f8c51c] flex items-center gap-3">
              <Clock size={24} className="text-[#f8c51c] shrink-0" />
              The Missing 30 Minutes
            </h3>
          </div>

          <p className="mt-4 max-w-4xl font-[family-name:var(--font-opensans)] text-sm sm:text-base leading-relaxed text-white/90">
            If AI cuts a task from 60 minutes to 30, most vendors report “30 minutes saved” and call
            it a win. We ask what happened to those 30 minutes. Did the employee use that capacity
            to improve quality, reduce backlog, or take on higher-value work? If nothing changed,
            you created efficiency without capturing value. That’s the gap we close.
          </p>

          <p className="mt-4 max-w-4xl font-[family-name:var(--font-opensans)] text-sm sm:text-base font-semibold leading-relaxed text-[#f8c51c]">
            The goal: Move from AI capability to captured organizational value. We measure every gap in
            the chain, so you know exactly where value is created and where it’s leaking.
          </p>
        </motion.div>
      </div>
    </section>
  );
};
