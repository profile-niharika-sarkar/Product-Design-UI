'use client';

import React from 'react';
import { motion } from 'motion/react';
import { Quote as QuoteIcon } from 'lucide-react';

export const Proof: React.FC = () => {
  const practiceAreas = [
    {
      area: 'Knowledge Architecture',
      impact: 'A shared prompt library and decision tools the whole team uses.',
    },
    {
      area: 'Intake & Triage',
      impact: 'Single entry point routes work to the right team with full context. No more dropped requests.',
    },
    {
      area: 'Analyst Engine',
      impact: 'AI-powered synthesis frees analysts to focus on judgment, not assembly. AI handles the first pass on synthesis, so analysts spend their time on judgment.',
    },
    {
      area: 'Dynamic Reporting',
      impact: 'Automated compilation and formatting. Researchers review and approve, not coordinate and compile.',
    },
    {
      area: 'AI as Thought Partner',
      impact: 'The executive director uses AI for strategic work, saving countless hours and unlocking opportunities for the team.',
    },
  ];

  const stakeholderVoices = [
    {
      role: 'Executive Director',
      quote: '“Structured AI assistants moved me from ‘doer’ to ‘approver.’ Executive bandwidth is now for strategy, not coordination.”',
    },
    {
      role: 'Research Lead',
      quote: '“AI handles synthesis. My analysts focus on what they’re actually trained for.”',
    },
    {
      role: 'Project Lead',
      quote: '“It’s a process redesign. That’s the difference.”',
    },
  ];

  return (
    <section
      id="proof"
      className="scroll-mt-24 bg-[#0c2940] py-16 sm:py-24 relative overflow-hidden border-b border-[#39918d]/25 text-white"
    >
      <div className="relative mx-auto max-w-[1484px] px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl"
        >
          <span className="font-[family-name:var(--font-montserrat)] text-xs font-bold uppercase tracking-[0.25em] text-[#39918d] bg-[#39918d]/15 border border-[#39918d]/30 px-3.5 py-1 rounded-full inline-block">
            PROOF: NCEMCH AT GEORGETOWN UNIVERSITY PARTNERSHIP
          </span>
          <h2 className="mt-3 font-[family-name:var(--font-montserrat)] text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white">
            Six months embedded. Here’s the full picture.
          </h2>
          <p className="mt-3 font-[family-name:var(--font-montserrat)] text-base sm:text-lg text-white/85">
            Projected annualized value from a 6-month embedded partnership.
          </p>
        </motion.div>

        {/* Practice Area & Impact Grid (#0c2940, #3f6d67, #f8c51c with white text) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.55, delay: 0.1 }}
          className="mt-10 overflow-hidden rounded-2xl border-2 border-[#3f6d67]/50 bg-[#0c2940] backdrop-blur-md shadow-2xl shadow-[#0c2940]/50 text-white"
        >
          {/* Table Header */}
          <div className="hidden bg-[#0c2940]/90 px-6 sm:px-7 py-4 sm:grid sm:grid-cols-[260px_1fr] items-center border-b border-[#3f6d67]/40">
            <span className="font-[family-name:var(--font-montserrat)] font-bold text-xs uppercase tracking-wider text-[#f8c51c]">
              Practice Area
            </span>
            <span className="font-[family-name:var(--font-montserrat)] font-bold text-xs uppercase tracking-wider text-[#f8c51c]">
              Impact
            </span>
          </div>

          {/* Table Rows - Responsive stacking on mobile */}
          {practiceAreas.map((item, index) => (
            <div
              key={index}
              className={`grid gap-2 px-6 sm:px-7 py-5 sm:grid-cols-[260px_1fr] sm:gap-6 transition-all duration-200 ${
                index < practiceAreas.length - 1 ? 'border-b border-[#3f6d67]/30' : ''
              } hover:bg-[#3f6d67]/25`}
            >
              <div>
                <span className="sm:hidden text-xs font-bold uppercase tracking-wider text-[#f8c51c] block mb-1">
                  Practice Area
                </span>
                <h3 className="font-[family-name:var(--font-montserrat)] font-medium text-sm sm:text-base text-white">
                  {item.area}
                </h3>
              </div>

              <div>
                <span className="sm:hidden text-xs font-bold uppercase tracking-wider text-[#39918d] block mb-1">
                  Impact
                </span>
                <p className="font-[family-name:var(--font-opensans)] text-sm sm:text-[15px] leading-relaxed text-white/95">
                  {item.impact}
                </p>
              </div>
            </div>
          ))}
        </motion.div>

        {/* Stakeholder Voices Header */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="mt-14"
        >
          <div className="flex items-center gap-2">
            <QuoteIcon size={20} className="text-[#f8c51c]" />
            <h3 className="font-[family-name:var(--font-montserrat)] font-medium text-xl sm:text-2xl text-white">
              Stakeholder Voices
            </h3>
          </div>
        </motion.div>

        {/* Testimonial Cards */}
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {stakeholderVoices.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              className="flex h-full flex-col justify-between rounded-2xl border-l-4 border-[#c57b4b] border-t border-r border-b border-[#39918d]/35 bg-[#3f6d67] p-6 sm:p-7 shadow-xl transition-all duration-300 hover:border-[#f8c51c] hover:shadow-[0_0_25px_rgba(248,197,28,0.25)] text-white"
            >
              <div>
                <p className="font-[family-name:var(--font-opensans)] italic text-sm sm:text-[15px] leading-relaxed text-white/90">
                  {item.quote}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-white/10">
                <h4 className="font-[family-name:var(--font-montserrat)] font-medium text-xs sm:text-sm uppercase tracking-wider text-[#f8c51c]">
                  {item.role}
                </h4>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Subtext */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5, delay: 0.25 }}
          className="mt-12 rounded-2xl border border-[#39918d]/35 bg-[#3f6d67] p-6 sm:p-7 text-center shadow-lg text-white/90"
        >
          <p className="font-[family-name:var(--font-opensans)] italic text-sm sm:text-base max-w-3xl mx-auto leading-relaxed">
            Federal agencies · Municipalities · Nonprofits · Private sector. The industries change,
            the framework adapts, the results stay consistent.
          </p>
        </motion.div>
      </div>
    </section>
  );
};
