'use client';

import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Calendar } from 'lucide-react';

interface ConsultationCTAProps {
  onOpenConsultation: () => void;
}

export const ConsultationCTA: React.FC<ConsultationCTAProps> = ({ onOpenConsultation }) => {
  const points = [
    'Where friction lives in your organization (redundant work, timelines, capability gaps)',
    'What success looks like for you (what changes, how the human experience improves, which metrics matter)',
    'Whether embedded partnership, custom workshops, or community learning makes sense',
  ];

  return (
    <section
      id="cta"
      className="scroll-mt-24 bg-[#0c2940] px-4 sm:px-6 lg:px-8 py-20 sm:py-28 relative overflow-hidden text-white"
    >
      <div className="relative mx-auto max-w-[1484px] w-full">
        {/* Main Title and Intro */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-3xl mx-auto"
        >
          <h2 className="font-[family-name:var(--font-montserrat)] text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white">
            Let’s Explore If Working Together Fits
          </h2>
          <p className="mt-4 text-center font-[family-name:var(--font-montserrat)] text-base sm:text-lg text-white/85 max-w-2xl mx-auto">
            One conversation. 30 minutes. Just clarity on whether this fits your situation.
          </p>
        </motion.div>

        {/* 3 Discussion Points - Full width matching the cards in sections above */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="mt-10 sm:mt-12 w-full"
        >
          <h3 className="font-[family-name:var(--font-montserrat)] font-medium text-sm sm:text-base uppercase tracking-wider text-[#f8c51c] mb-6 text-center md:text-left">
            We’ll work together to understand:
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full items-stretch">
            {points.map((item, idx) => (
              <motion.div
                key={idx}
                className="flex items-start gap-4 rounded-2xl p-6 sm:p-7 border-2 border-[#39918d]/35 bg-[#3f6d67] text-white shadow-xl hover:border-[#f8c51c]/60 transition-all duration-300"
              >
                <span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-[#c57b4b]" />
                <span className="font-[family-name:var(--font-opensans)] text-sm sm:text-base leading-relaxed text-white/95">
                  {item}
                </span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Action Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mt-12 sm:mt-14 text-center"
        >
          <button
            onClick={onOpenConsultation}
            className="group inline-flex items-center gap-2.5 rounded-full px-8 sm:px-10 py-4 sm:py-4.5 font-[family-name:var(--font-montserrat)] text-sm font-bold uppercase tracking-wide bg-[#f8c51c] text-[#0c2940] transition-all duration-200 hover:bg-white hover:text-[#0c2940] hover:shadow-2xl hover:shadow-[#f8c51c]/40 active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
          >
            <Calendar size={18} className="shrink-0" />
            <span>SCHEDULE ORGANIZATIONAL CONSULTATION</span>
            <ArrowRight
              size={15}
              className="transition-transform duration-200 group-hover:translate-x-1"
            />
          </button>
        </motion.div>
      </div>
    </section>
  );
};
