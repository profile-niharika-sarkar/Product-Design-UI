'use client';

import React from 'react';
import { motion } from 'motion/react';
import { Quote } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      n: '01',
      title: 'Expertise Capture',
      desc: 'Trapped expertise becomes structured, market-ready training assets.',
    },
    {
      n: '02',
      title: 'Guided AI Co-Creation',
      desc: 'An AI assistant guides your experts step by step. No blank-page friction.',
    },
    {
      n: '03',
      title: 'Actionable Program Design',
      desc: 'Every module produces a hands-on framework: scorecards, decision maps, trackers learners use immediately.',
    },
    {
      n: '04',
      title: 'Performance Alignment',
      desc: 'A direct line from learning activities to observable workplace metrics.',
    },
  ];

  return (
    <section
      id="how"
      className="scroll-mt-24 bg-[#f5f8f7] py-16 sm:py-24 border-b border-[#39918d]/25 text-[#0c2940] relative overflow-hidden"
    >
      <div className="mx-auto max-w-[1484px] px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl"
        >
          <span className="font-[family-name:var(--font-montserrat)] text-xs font-bold uppercase tracking-[0.25em] text-[#3f6d67] bg-[#3f6d67]/10 border border-[#3f6d67]/25 px-3.5 py-1.5 rounded-full inline-block">
            HOW IT WORKS
          </span>
          <h2 className="mt-3 font-[family-name:var(--font-montserrat)] text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-[#0c2940]">
            Learning Architecture in four steps
          </h2>
        </motion.div>

        {/* 4 Steps Cards in Light Mixed Styling */}
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4 items-stretch">
          {steps.map((step, idx) => (
            <motion.div
              key={step.n}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              className="flex flex-col justify-between rounded-2xl border-2 border-[#39918d]/25 bg-white p-6 sm:p-7 shadow-lg shadow-[#0c2940]/5 transition-all duration-300 hover:border-[#f8c51c] hover:shadow-[0_0_25px_rgba(248,197,28,0.3)] text-[#0c2940]"
            >
              <div>
                <span className="font-[family-name:var(--font-montserrat)] text-2xl sm:text-3xl font-bold text-[#39918d] block">
                  {step.n}
                </span>

                <h3 className="mt-3 font-[family-name:var(--font-montserrat)] font-medium text-base sm:text-lg text-[#0c2940]">
                  {step.title}
                </h3>

                <p className="mt-2 font-[family-name:var(--font-opensans)] text-sm sm:text-[15px] leading-relaxed text-[#0c2940]/80">
                  {step.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Quote Callout with Terracotta (#c57b4b) Accent */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mt-10 border-l-4 border-[#c57b4b] pl-5 sm:pl-6 py-4 rounded-r-2xl bg-[#c57b4b]/10 shadow-sm"
        >
          <div className="flex items-start gap-3">
            <Quote size={22} className="text-[#c57b4b] shrink-0 mt-0.5" />
            <p className="font-[family-name:var(--font-opensans)] italic text-base sm:text-lg leading-relaxed text-[#0c2940]/90">
              “One of the best succession planning initiatives you can do is a project like this.”
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
