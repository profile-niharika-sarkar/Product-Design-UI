'use client';

import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Quote } from 'lucide-react';

interface CommunityProps {
  onOpenConsultation?: () => void;
}

export const Community: React.FC<CommunityProps> = () => {
  return (
    <section
      id="community"
      className="scroll-mt-24 bg-[#0c2940] py-16 sm:py-24 border-b border-[#39918d]/25 text-white relative overflow-hidden"
    >
      <div className="mx-auto max-w-[1484px] px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl"
        >
          <span className="font-[family-name:var(--font-montserrat)] text-xs font-bold uppercase tracking-[0.25em] text-[#39918d] bg-[#39918d]/15 border border-[#39918d]/30 px-3.5 py-1 rounded-full inline-block">
            COMMUNITY
          </span>
          <h2 className="mt-3 font-[family-name:var(--font-montserrat)] text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white">
            Start With Curiosity
          </h2>
          <p className="mt-4 font-[family-name:var(--font-montserrat)] text-base sm:text-lg leading-relaxed text-white/85">
            Free 30-minute consultation, community of practice, and custom workshops for organizations
            of every size.
          </p>
        </motion.div>

        {/* Action Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="mt-8 flex flex-wrap items-center gap-4"
        >
          <a
            href="https://maven.com/paige-bradbury/ai-cohort-4-ai-and-performance-measurement-in-learning-development"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full px-7 py-3.5 font-[family-name:var(--font-montserrat)] text-sm font-bold uppercase tracking-wide bg-[#f8c51c] text-[#0c2940] transition-all duration-200 hover:bg-white hover:text-[#0c2940] hover:shadow-lg hover:shadow-[#f8c51c]/35 active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
          >
            <span>Explore community & workshops</span>
            <ArrowRight size={15} />
          </a>
        </motion.div>

        {/* Quote Callout */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5, delay: 0.25 }}
          className="mt-10 border-l-4 border-[#c57b4b] pl-5 sm:pl-6 py-4 rounded-r-2xl bg-[#3f6d67] shadow-lg max-w-4xl"
        >
          <div className="flex items-start gap-3">
            <Quote size={22} className="text-[#c57b4b] shrink-0 mt-0.5" />
            <p className="font-[family-name:var(--font-opensans)] italic text-base sm:text-lg leading-relaxed text-white/95">
              “Free learning is how the best partnerships begin. People show up curious, bring real questions, and the relationship evolves from there.”
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
