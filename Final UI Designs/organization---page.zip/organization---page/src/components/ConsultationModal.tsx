'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, Clock, Building2, Mail, User, ArrowRight } from 'lucide-react';

const GOOGLE_APPOINTMENT_URL =
  'https://calendar.google.com/calendar/appointments/schedules/AcZssZ02gbI3oOoAkk6FnRZpu6RUQTiAo23ewsroiiCMwZD_Jcf8yRwqAFRAz11Xy9kDhIE10O74E_Yp?gv=true';

interface ConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialScope?: string;
}

export const ConsultationModal: React.FC<ConsultationModalProps> = ({
  isOpen,
  onClose,
  initialScope = 'Pilot',
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [orgName, setOrgName] = useState('');
  const [orgType, setOrgType] = useState('Nonprofits');
  const [scope, setScope] = useState(initialScope);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  // Lock background scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = 'unset';
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [isOpen, onClose]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !orgName) return;
    setSubmitted(true);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#0c2940]/80 backdrop-blur-md"
            aria-hidden="true"
          />

          {/* Modal Container in Navy & Teal Theme */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className={`relative w-full ${
              submitted ? 'max-w-5xl max-h-[92vh] overflow-y-auto' : 'max-w-xl'
            } rounded-2xl border-2 border-[#39918d]/40 bg-[#0c2940] p-5 sm:p-8 text-white shadow-2xl z-10 my-6`}
            role="dialog"
            aria-modal="true"
            aria-labelledby="consultation-modal-title"
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 sm:top-5 sm:right-5 p-2 rounded-full text-white/70 hover:text-white hover:bg-white/10 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#f8c51c]"
              aria-label="Close dialog"
            >
              <X size={20} />
            </button>

            {!submitted ? (
              <div>
                <div className="flex items-center gap-2 mb-2 font-[family-name:var(--font-montserrat)] text-xs font-bold uppercase tracking-[0.2em] text-[#f8c51c]">
                  <Clock size={14} />
                  <span>30-Minute Discovery Session</span>
                </div>
                <h3
                  id="consultation-modal-title"
                  className="font-[family-name:var(--font-montserrat)] text-xl sm:text-2xl font-bold tracking-tight text-white"
                >
                  Schedule Organizational Consultation
                </h3>
                <p className="mt-2 font-[family-name:var(--font-opensans)] text-xs sm:text-sm leading-relaxed text-white/80">
                  One conversation. 30 minutes. Just clarity on whether this fits your situation.
                </p>

                <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-[family-name:var(--font-montserrat)] text-xs font-semibold mb-1.5 text-white/90">
                        Your Name
                      </label>
                      <div className="relative">
                        <User size={15} className="absolute left-3.5 top-3.5 text-white/40" />
                        <input
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="e.g. Dr. Sarah Jenkins"
                          className="w-full rounded-xl pl-10 pr-3.5 py-2.5 font-[family-name:var(--font-opensans)] text-sm bg-[#0c2940]/90 border border-[#39918d]/40 text-white placeholder-white/40 focus:border-[#f8c51c] focus:ring-1 focus:ring-[#f8c51c] focus:outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block font-[family-name:var(--font-montserrat)] text-xs font-semibold mb-1.5 text-white/90">
                        Work Email
                      </label>
                      <div className="relative">
                        <Mail size={15} className="absolute left-3.5 top-3.5 text-white/40" />
                        <input
                          type="email"
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="name@organization.gov / .org"
                          className="w-full rounded-xl pl-10 pr-3.5 py-2.5 font-[family-name:var(--font-opensans)] text-sm bg-[#0c2940]/90 border border-[#39918d]/40 text-white placeholder-white/40 focus:border-[#f8c51c] focus:ring-1 focus:ring-[#f8c51c] focus:outline-none transition-all"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-[family-name:var(--font-montserrat)] text-xs font-semibold mb-1.5 text-white/90">
                        Organization Name
                      </label>
                      <div className="relative">
                        <Building2 size={15} className="absolute left-3.5 top-3.5 text-white/40" />
                        <input
                          type="text"
                          required
                          value={orgName}
                          onChange={(e) => setOrgName(e.target.value)}
                          placeholder="e.g. NCEMCH / Georgetown"
                          className="w-full rounded-xl pl-10 pr-3.5 py-2.5 font-[family-name:var(--font-opensans)] text-sm bg-[#0c2940]/90 border border-[#39918d]/40 text-white placeholder-white/40 focus:border-[#f8c51c] focus:ring-1 focus:ring-[#f8c51c] focus:outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block font-[family-name:var(--font-montserrat)] text-xs font-semibold mb-1.5 text-white/90">
                        Organization Type
                      </label>
                      <select
                        value={orgType}
                        onChange={(e) => setOrgType(e.target.value)}
                        className="w-full rounded-xl px-3.5 py-2.5 font-[family-name:var(--font-opensans)] text-sm bg-[#0c2940]/90 border border-[#39918d]/40 text-white focus:border-[#f8c51c] focus:ring-1 focus:ring-[#f8c51c] focus:outline-none transition-all"
                      >
                        <option value="Federal agencies">Federal agencies</option>
                        <option value="Municipalities">Municipalities</option>
                        <option value="Nonprofits">Nonprofits</option>
                        <option value="Private sector">Private sector</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block font-[family-name:var(--font-montserrat)] text-xs font-semibold mb-1.5 text-white/90">
                      Engagement Scope Interest
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {['Pilot', 'How It Works', 'Transform'].map((option) => (
                        <button
                          key={option}
                          type="button"
                          onClick={() => setScope(option)}
                          className={`py-2 px-2.5 rounded-lg text-xs font-[family-name:var(--font-montserrat)] font-semibold border transition-all ${
                            scope === option
                              ? 'border-[#f8c51c] bg-[#f8c51c]/20 text-[#f8c51c]'
                              : 'border-[#39918d]/30 bg-[#0c2940]/60 text-white/70 hover:bg-[#39918d]/20'
                          }`}
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full inline-flex items-center justify-center gap-2 rounded-full py-3.5 px-6 font-[family-name:var(--font-montserrat)] text-sm font-bold uppercase tracking-wide bg-[#f8c51c] text-[#0c2940] hover:bg-white hover:text-[#0c2940] transition-all duration-150 hover:shadow-lg hover:shadow-[#f8c51c]/35 active:scale-98 focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
                    >
                      <Calendar size={16} />
                      <span>Continue to Choose a Time</span>
                      <ArrowRight size={15} />
                    </button>
                  </div>

                  <p className="text-center font-[family-name:var(--font-opensans)] text-[11px] text-white/60">
                    Choose a time on the next step · No obligation
                  </p>
                </form>
              </div>
            ) : (
              <div className="pt-2">
                <div className="mb-5 pr-10">
                  <div className="flex items-center gap-2 mb-2 font-[family-name:var(--font-montserrat)] text-xs font-bold uppercase tracking-[0.2em] text-[#f8c51c]">
                    <Clock size={14} />
                    <span>Choose Your Consultation Time</span>
                  </div>
                  <h4
                    id="consultation-modal-title"
                    className="font-[family-name:var(--font-montserrat)] text-xl sm:text-2xl font-bold text-white"
                  >
                    Schedule with Google Calendar
                  </h4>
                  <p className="mt-2 font-[family-name:var(--font-opensans)] text-xs sm:text-sm leading-relaxed text-white/80">
                    Booking for {name} at {orgName} ({scope} scope). Select an available time below.
                  </p>
                </div>

                <iframe
                  src={GOOGLE_APPOINTMENT_URL}
                  title="Google Calendar consultation appointment scheduler"
                  className="block w-full rounded-xl border border-[#39918d]/35 bg-white"
                  height="600"
                  loading="lazy"
                />

                <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                  <p className="font-[family-name:var(--font-opensans)] text-xs sm:text-sm text-white/70">
                    Calendar details will be confirmed by Google Calendar.
                  </p>
                  <button
                    type="button"
                    onClick={() => setSubmitted(false)}
                    className="inline-flex min-h-10 items-center justify-center rounded-full border border-white/35 px-5 py-2 font-[family-name:var(--font-montserrat)] text-xs sm:text-sm font-semibold text-white transition-colors hover:bg-white/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#f8c51c]"
                  >
                    Edit details
                  </button>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
