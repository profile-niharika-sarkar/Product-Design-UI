'use client';

import React, { useState } from 'react';
import { Hero } from './components/Hero';
import { HowItWorks } from './components/HowItWorks';
import { Proof } from './components/Proof';
import { EngagementPaths } from './components/EngagementPaths';
import { Community } from './components/Community';
import { ValueGaps } from './components/ValueGaps';
import { ConsultationCTA } from './components/ConsultationCTA';
import { ConsultationModal } from './components/ConsultationModal';

export default function App() {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedScope, setSelectedScope] = useState('Pilot');

  const handleOpenConsultation = (scope = 'Pilot') => {
    setSelectedScope(scope);
    setModalOpen(true);
  };

  const handleCloseConsultation = () => {
    setModalOpen(false);
  };

  return (
    <div className="relative min-h-screen bg-navy font-['Open_Sans'] antialiased flex flex-col selection:bg-gold selection:text-navy overflow-x-hidden">
      {/* Main Content: Harmonious Alternating Mix of Dark and Light Sections */}
      <main className="relative z-10 flex-1">
        <Hero onOpenConsultation={() => handleOpenConsultation('Pilot')} />
        <HowItWorks />
        <Proof />
        <EngagementPaths onSelectScope={handleOpenConsultation} />
        <Community onOpenConsultation={() => handleOpenConsultation('Community & Workshops')} />
        <ValueGaps />
        <ConsultationCTA onOpenConsultation={() => handleOpenConsultation('Pilot')} />
      </main>

      {/* Interactive Consultation Scheduler Dialog with Google Calendar */}
      <ConsultationModal
        isOpen={modalOpen}
        onClose={handleCloseConsultation}
        initialScope={selectedScope}
      />
    </div>
  );
}
