import React, { useState } from 'react';
import { Section1Hero } from './components/Section1Hero';
import { Section2Proof } from './components/Section2Proof';
import { Section3DelayedGratification } from './components/Section3DelayedGratification';
import { Section6Reimbursement } from './components/Section6Reimbursement';
import { Section7WalterTrack } from './components/Section7WalterTrack';
import { Section8ClosingCta } from './components/Section8ClosingCta';

import { TaxGuideModal } from './components/TaxGuideModal';

export default function App() {
  const [isTaxGuideModalOpen, setIsTaxGuideModalOpen] = useState(false);

  const scrollToEnrollForm = () => {
    const el = document.getElementById('closing-cta');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#ffffff] text-[#0c2940] flex flex-col font-sans selection:bg-[#f8c51c] selection:text-[#0c2940]">
      {/* HEADER REMOVED COMPLETELY */}

      {/* Section 1: HERO */}
      <Section1Hero
        onEnrollDirectly={scrollToEnrollForm}
      />

      {/* Section 2: THE PROOF (Andy Ivey) */}
      <Section2Proof />

      {/* Section 3: Delayed Gratification */}
      <Section3DelayedGratification />

      {/* Section 6: REIMBURSEMENT (IRC Section 162) */}
      <Section6Reimbursement
        onDownloadTaxGuide={() => setIsTaxGuideModalOpen(true)}
      />

      {/* Section 7: WALTER TRACK */}
      <Section7WalterTrack />

      {/* Section 8: CLOSING CTA */}
      <Section8ClosingCta />



      {/* Tax Guide Modal */}
      <TaxGuideModal
        isOpen={isTaxGuideModalOpen}
        onClose={() => setIsTaxGuideModalOpen(false)}
      />
    </div>
  );
}
