'use client';

import React from 'react';
import { Sprout } from 'lucide-react';

export const Section3DelayedGratification: React.FC = () => {
  const stages = [
    {
      stage: 'STAGE 1',
      title: 'Choose to Start',
      caption: "You don't need to feel ready. You just need to begin.",
    },
    {
      stage: 'STAGE 2',
      title: 'Emotions Surface',
      caption: "Doubt shows up early. That's normal, and we plan for it.",
    },
    {
      stage: 'STAGE 3',
      title: 'The Aha Moment',
      caption: 'Your first real win, on your own real work.',
    },
    {
      stage: 'STAGE 4',
      title: 'The Messy Middle',
      caption: 'Progress feels uneven here. This is where coaching matters most.',
    },
    {
      stage: 'STAGE 5',
      title: 'Momentum Builds',
      caption: 'Small wins add up to time and value you can measure.',
    },
  ];

  return (
    <section className="bg-[#0c2940] text-white py-20 lg:py-24 border-b border-[#39918d]/20 relative overflow-hidden">
      <div className="max-w-[1484px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div 
            style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
            className="text-xs font-bold tracking-widest text-[#f8c51c] uppercase mb-3"
          >
            DELAYED GRATIFICATION
          </div>
          <h2 
            style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
            className="text-3xl sm:text-4xl lg:text-[44px] font-bold text-white tracking-tight leading-tight mb-3"
          >
            Go slow first. Go fast later.
          </h2>
          <p 
            style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
            className="text-sm sm:text-base text-slate-300 font-normal leading-relaxed"
          >
            AI adoption follows a growth pattern. We built the journey around it.
          </p>
        </div>

        {/* 5 Stages Grid matching screenshot layout & typography */}
        <div className="w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 lg:gap-5 mb-10">
          {stages.map((item, index) => (
            <div 
              key={index}
              className="bg-[#0c2940]/90 border border-[#39918d]/30 rounded-2xl p-6 sm:p-7 flex flex-col justify-between hover:border-[#39918d]/60 transition-all duration-200"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span 
                    style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
                    className="text-xs font-bold tracking-wider text-white uppercase"
                  >
                    {item.stage}
                  </span>
                  <Sprout className="w-4 h-4 text-[#39918d]" />
                </div>
                <h3 
                  style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
                  className="text-xl sm:text-2xl font-bold text-white mb-4 leading-snug"
                >
                  {item.title}
                </h3>
              </div>
              <p 
                style={{ fontFamily: 'var(--font-opensans), sans-serif' }}
                className="text-xs sm:text-sm text-slate-300 italic leading-relaxed"
              >
                {item.caption}
              </p>
            </div>
          ))}
        </div>

        {/* Image displayed at its natural aspect ratio to avoid cropping */}
        <div className="w-full mb-10">
          <div
            className="w-full overflow-hidden rounded-2xl border border-[#39918d]/40 bg-[#3f6d67]/10"
            style={{ width: '100%', maxWidth: '1484px', marginInline: 'auto' }}
          >
            <img
              src="/Home-image.png"
              alt=""
              className="block h-auto w-full object-contain"
            />
          </div>
        </div>

        {/* Quote Block matching screenshot */}
        <div className="w-full bg-[#0c2940]/90 border border-[#39918d]/30 rounded-2xl p-7 sm:p-9 shadow-lg">
          <blockquote 
            style={{ fontFamily: 'var(--font-opensans), sans-serif' }}
            className="text-sm sm:text-base text-white/95 italic leading-relaxed mb-6 font-normal"
          >
            “We’ve been conditioned for instant gratification. AI requires something different. It requires you to think deeper, iterate, and be comfortable with not knowing immediately. But for leaders brave enough to go slow first and go fast later, the dividends are extraordinary.”
          </blockquote>
          <div className="border-t border-white/10 pt-4">
            <p 
              style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
              className="text-sm font-semibold text-white/90"
            >
              Paige Bradbury, CEO & Principal Learning Architect
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
