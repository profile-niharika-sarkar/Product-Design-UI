'use client';

import React from 'react';
import { ArrowRight } from 'lucide-react';
import { ParticleBackground } from '@/components/ui/ParticleBackground';

interface Section1HeroProps {
  onEnrollDirectly: () => void;
}

export const Section1Hero: React.FC<Section1HeroProps> = ({
  onEnrollDirectly,
}) => {
  return (
    <section className="relative bg-[#0c2940] text-white pt-20 pb-20 md:pt-24 md:pb-24 lg:pt-28 lg:pb-28 overflow-hidden border-b border-[#39918d]/20">
      {/* Decorative network layer with 50% opacity continuously animating */}
      <ParticleBackground variant="dark" opacity={0.5} lineRgb="57, 145, 141" />

      {/* Subtle ambient lighting */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#39918d]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-80 h-80 bg-[#c57b4b]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-[1484px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-center">
          
          {/* Left Column: Hero Narrative */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {/* H1 */}
            <h1 
              style={{ fontFamily: 'var(--font-inter), sans-serif' }}
              className="text-3xl sm:text-4xl lg:text-[46px] xl:text-[52px] font-extrabold text-white tracking-tight leading-[1.12] mb-6"
            >
              “I’m terrified of AI. I don’t<br className="hidden sm:inline" /> know where to start.”
            </h1>

            {/* Sub */}
            <h2 
              style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
              className="text-lg sm:text-xl lg:text-[22px] font-bold text-white leading-snug mb-5 max-w-xl"
            >
              From paralysis to fluency in 12 weeks.<br className="hidden sm:inline" /> This is what one nonprofit leader<br className="hidden sm:inline" /> discovered, and what’s waiting for you.
            </h2>

            {/* Body */}
            <p 
              style={{ fontFamily: 'var(--font-opensans), sans-serif' }}
              className="text-sm sm:text-base text-slate-200 leading-relaxed mb-8 max-w-lg font-normal"
            >
              Every discovery call I take, the story is the same: leaders who know AI is non-negotiable, but who are skeptical or terrified of getting it wrong.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 mb-4">
              <button
                onClick={onEnrollDirectly}
                style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
                className="px-6 py-3.5 bg-[#3f6d67] hover:bg-[#345c57] text-white font-bold text-xs sm:text-sm tracking-wider uppercase rounded-lg border border-[#39918d]/40 transition-all duration-200 active:scale-[0.99] flex items-center space-x-2 shadow-sm"
              >
                <span>ENROLL DIRECTLY</span>
                <ArrowRight className="w-4 h-4 text-[#f8c51c]" />
              </button>
            </div>
          </div>

          {/* Right Column: Hero Card with yellow/gold border matching screenshot */}
          <div className="lg:col-span-5">
            <div className="bg-[#0c2940]/90 backdrop-blur-md border border-[#f8c51c]/60 rounded-2xl shadow-2xl relative overflow-hidden transition-all duration-300">
              <div className="p-7 sm:p-8 pb-6">
                {/* Card Header */}
                <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-5">
                  <span 
                    style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
                    className="text-xs font-bold tracking-widest text-white uppercase"
                  >
                    PARTICIPANT FILE / 001
                  </span>
                  <span className="w-2 h-2 rounded-full bg-[#f8c51c]" />
                </div>

                {/* Quote */}
                <blockquote 
                  style={{ fontFamily: 'var(--font-opensans), sans-serif' }}
                  className="text-sm sm:text-base text-white/95 italic leading-relaxed mb-5 font-normal"
                >
                  “I walked in convinced this wasn’t for me. I walked out with a 5-year strategic plan, three custom AI assistants, and a clear path to scale my impact without scaling my team.”
                </blockquote>

                {/* Attribution */}
                <div className="border-t border-white/10 pt-4">
                  <p 
                    style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
                    className="text-sm font-semibold text-white leading-snug"
                  >
                    Andy Ivey, Fundraising Lead, Family Legacy. 8,000 sponsored children in Zambia.
                  </p>
                </div>
              </div>

              {/* Bottom bar in flush teal with white text matching screenshot */}
              <div className="bg-[#3f6d67] px-7 sm:px-8 py-3.5 flex items-center justify-between border-t border-[#39918d]/40">
                <span 
                  style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
                  className="text-xs font-bold tracking-wider text-white uppercase"
                >
                  SIX WEEKS LATER
                </span>
                <span 
                  style={{ fontFamily: 'var(--font-inter), sans-serif' }}
                  className="text-base sm:text-lg font-bold text-white tracking-tight"
                >
                  $62,224
                </span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
