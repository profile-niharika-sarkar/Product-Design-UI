'use client';

import React from 'react';
import { ArrowRight, Building2 } from 'lucide-react';

interface LinkProps {
  href: string;
  className?: string;
  style?: React.CSSProperties;
  children: React.ReactNode;
}

const Link: React.FC<LinkProps> = ({ href, className, style, children }) => (
  <a href={href} className={className} style={style}>
    {children}
  </a>
);

export const Section7WalterTrack: React.FC = () => {
  return (
    <section className="bg-[#0c2940] text-white py-10 sm:py-14 lg:py-16 border-b border-[#39918d]/20">
      <div className="max-w-[1484px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="w-full bg-[#133543]/70 border border-[#39918d]/40 rounded-2xl px-6 py-5 sm:px-8 sm:py-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 shadow-lg">
          
          {/* Left Text Block */}
          <div className="flex flex-col justify-center">
            <div className="flex items-center space-x-2 mb-1.5">
              <Building2 className="w-4 h-4 text-[#f8c51c]" />
              <span 
                style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
                className="text-[11px] sm:text-xs font-bold tracking-widest text-white uppercase"
              >
                WALTER TRACK
              </span>
            </div>
            <p 
              style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
              className="text-sm sm:text-[15px] font-semibold text-white leading-normal"
            >
              Rolling AI out across departments instead? For Organizations is the page you want.
            </p>
          </div>

          {/* Right Action Button */}
          <Link
            href="/organisation"
            style={{ fontFamily: 'var(--font-montserrat), sans-serif' }}
            className="self-start sm:self-center shrink-0 px-5 py-2.5 bg-[#39918d] hover:bg-[#327e7a] text-white text-xs sm:text-[13px] font-bold tracking-wider uppercase rounded-lg transition-all duration-200 flex items-center space-x-2 shadow-sm"
          >
            <span>FOR ORGANIZATIONS</span>
            <ArrowRight className="w-4 h-4 text-white" />
          </Link>

        </div>
      </div>
    </section>
  );
};
