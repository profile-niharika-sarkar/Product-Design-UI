<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/a49f34d6-cb36-43d9-94e8-ac30c9179ce1

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key.
3. To enable booking requests, configure `RESEND_API_KEY` and `RESEND_FROM_EMAIL` in the server environment. The sender domain must be verified with Resend. Never expose the Resend API key in client-side code.
4. Run the app:
   `npm run dev`

The booking form emails requests to `admin@thebradburygroup.net` and opens the Google Calendar appointment page after the email is accepted. `npm run start` serves the production build and the booking API; run `npm run build` first.
