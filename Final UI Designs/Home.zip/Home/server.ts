import dotenv from 'dotenv';
import express from 'express';
import { resolve } from 'node:path';
import { createServer as createViteServer } from 'vite';

dotenv.config({ path: ['.env.local', '.env'] });

interface BookingPayload {
  name: string;
  email: string;
  company: string;
  path: 'For You' | 'For Leaders' | 'For Organizations';
  notes: string;
}

const validPaths = ['For You', 'For Leaders', 'For Organizations'];

function isBookingPath(value: string): value is BookingPayload['path'] {
  return validPaths.includes(value);
}

function isBookingPayload(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function readBookingPayload(value: unknown): BookingPayload | null {
  if (!isBookingPayload(value)) return null;

  const { name, email, company = '', path, notes = '' } = value;
  if (
    typeof name !== 'string' ||
    typeof email !== 'string' ||
    typeof company !== 'string' ||
    typeof path !== 'string' ||
    typeof notes !== 'string'
  ) {
    return null;
  }

  if (!isBookingPath(path)) return null;

  const booking = {
    name: name.trim(),
    email: email.trim(),
    company: company.trim(),
    path,
    notes: notes.trim(),
  };

  if (
    !booking.name ||
    booking.name.length > 200 ||
    booking.email.length > 254 ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(booking.email) ||
    booking.company.length > 200 ||
    booking.notes.length > 4000
  ) {
    return null;
  }

  return booking;
}

const app = express();
app.use(express.json({ limit: '12kb' }));

app.post('/api/booking', async (request, response) => {
  const booking = readBookingPayload(request.body);
  if (!booking) {
    response.status(400).json({ error: 'Please check the booking details and try again.' });
    return;
  }

  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.RESEND_FROM_EMAIL;
  if (!apiKey || !from) {
    console.error('Booking email is not configured: RESEND_API_KEY and RESEND_FROM_EMAIL are required.');
    response.status(503).json({
      error: 'Booking email is not configured yet. Please contact us directly.',
    });
    return;
  }

  const emailBody = [
    'A new 30-minute discovery session was requested.',
    '',
    `Name: ${booking.name}`,
    `Email: ${booking.email}`,
    `Organization / Company: ${booking.company || 'Not provided'}`,
    `Primary Focus Path: ${booking.path}`,
    `Key Objectives / Notes: ${booking.notes || 'Not provided'}`,
  ].join('\n');

  try {
    const resendResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from,
        to: ['admin@thebradburygroup.net'],
        reply_to: booking.email,
        subject: `New discovery session request from ${booking.name}`,
        text: emailBody,
      }),
    });

    if (!resendResponse.ok) {
      console.error(`Resend rejected a booking email with status ${resendResponse.status}.`);
      response.status(502).json({
        error: 'We could not send your request right now. Please try again shortly.',
      });
      return;
    }

    response.status(200).json({ ok: true });
  } catch (error) {
    console.error('Failed to deliver booking email through Resend.', error);
    response.status(502).json({
      error: 'We could not send your request right now. Please try again shortly.',
    });
  }
});

const port = Number(process.env.PORT || 3000);
const isProduction =
  process.argv.includes('--production') || process.env.NODE_ENV === 'production';

if (isProduction) {
  const distDirectory = resolve(process.cwd(), 'dist');
  app.use(express.static(distDirectory));
  app.get('*', (_request, response) => {
    response.sendFile(resolve(distDirectory, 'index.html'));
  });
} else {
  const vite = await createViteServer({
    appType: 'spa',
    server: { middlewareMode: true },
  });
  app.use(vite.middlewares);
}

app.listen(port, '0.0.0.0', () => {
  console.log(`Booking app listening on http://localhost:${port}`);
});
