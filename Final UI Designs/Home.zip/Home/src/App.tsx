/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Hero } from './components/Hero';
import { Testimonials } from './components/Testimonials';
import { MeetColumbus } from './components/MeetColumbus';
import { GrowthPath } from './components/GrowthPath';
import { OperatingPrinciples } from './components/OperatingPrinciples';
import { StrategicEngagement } from './components/StrategicEngagement';
import { CtaBanner } from './components/CtaBanner';
import { ColumbusModal } from './components/ColumbusModal';
import { AssessmentModal } from './components/AssessmentModal';

const CALENDAR_APPOINTMENT_URL =
  'https://calendar.google.com/calendar/u/0/appointments/schedules/AcZssZ02gbI3oOoAkk6FnRZpu6RUQTiAo23ewsroiiCMwZD_Jcf8yRwqAFRAz11Xy9kDhIE10O74E_Yp';

export default function App() {
  const [isColumbusOpen, setIsColumbusOpen] = useState(false);
  const [isAssessmentOpen, setIsAssessmentOpen] = useState(false);
  const [assessmentStage, setAssessmentStage] = useState<string | undefined>(undefined);

  const openCalendar = () => {
    window.location.assign(CALENDAR_APPOINTMENT_URL);
  };

  const handleOpenAssessment = (stage?: string) => {
    setAssessmentStage(stage);
    setIsAssessmentOpen(true);
  };

  return (
    <main className="w-full min-h-screen bg-white text-[#0c2940] selection:bg-[#f8c51c] selection:text-[#0c2940]">
      {/* SECTION 1: HERO */}
      <Hero />

      {/* SECTION 2 & 3: MEET COLUMBUS & GROWTH PATH (SEAMLESS DARK NAVY CONTAINER) */}
      <div className="w-full bg-[#00101F]">
        <MeetColumbus onOpenColumbus={() => setIsColumbusOpen(true)} />
        <GrowthPath onOpenAssessment={handleOpenAssessment} />
      </div>

      {/* SECTION 4: OPERATING PRINCIPLES (HOW WE'RE DIFFERENT) */}
      <OperatingPrinciples />

      {/* SECTION 5: STRATEGIC ENGAGEMENT (ALREADY KNOW WHAT YOU NEED? EXPLORE DIRECTLY.) */}
      <StrategicEngagement />

      <Testimonials />

      {/* SECTION 6: CTA BANNER (NOT SURE WHICH PATH IS RIGHT FOR YOU?) */}
      <CtaBanner onOpenBooking={openCalendar} />

      {/* INTERACTIVE MODALS */}
      <ColumbusModal
        isOpen={isColumbusOpen}
        onClose={() => setIsColumbusOpen(false)}
        onOpenBooking={() => {
          setIsColumbusOpen(false);
          openCalendar();
        }}
      />

      <AssessmentModal
        isOpen={isAssessmentOpen}
        onClose={() => setIsAssessmentOpen(false)}
        initialStage={assessmentStage}
        onOpenBooking={() => {
          setIsAssessmentOpen(false);
          openCalendar();
        }}
      />
    </main>
  );
}
