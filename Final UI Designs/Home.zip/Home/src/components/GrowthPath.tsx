'use client';

import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import growthBgImage from 'Public/Home-image.png';

interface GrowthPathProps {
  onOpenAssessment: (stage?: string) => void;
}

const STAGES = [
  {
    id: 'start',
    name: 'Choose to Start',
    x: '14%',
    y: '78%',
    description: 'A single seed and a choice to begin, before feeling ready.',
  },
  {
    id: 'emotions',
    name: 'Emotions Surface',
    x: '32%',
    y: '56%',
    description: 'Doubt and friction surface early — this is normal and planned for.',
  },
  {
    id: 'aha',
    name: 'The Aha Moment',
    x: '52%',
    y: '38%',
    description: 'The first real win lands on your own work, and things click.',
  },
  {
    id: 'messy',
    name: 'The Messy Middle',
    x: '72%',
    y: '46%',
    description: 'Progress loops back on itself. Where coaching matters most.',
  },
  {
    id: 'momentum',
    name: 'Momentum Builds',
    x: '88%',
    y: '22%',
    description: 'Small wins compound into measurable enterprise velocity.',
  },
];

export const GrowthPath: React.FC<GrowthPathProps> = ({ onOpenAssessment }) => {
  const [activeStage, setActiveStage] = useState<string | null>(null);

  return (
    <section
      id="growth-path"
      className="w-full bg-[#00101F] text-white px-4 sm:px-6 lg:px-8 pt-6 pb-20 sm:pb-28"
    >
      <div className="w-full max-w-[1420px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* LEFT COLUMN: TEXT CONTENT */}
          <div className="lg:col-span-5 flex flex-col justify-center">
            <h2
              className="
                font-inter
                text-3xl
                sm:text-4xl
                lg:text-[2.75rem]
                font-bold
                leading-[1.15]
                tracking-[-0.03em]
                text-white
                mb-6
              "
            >
              Growth Doesn&apos;t Move in a Straight Line
            </h2>

            <div className="space-y-4 font-roboto text-sm sm:text-base text-slate-300 leading-relaxed">
              <p>
                Every team we work with starts at the same place: a single seed
                and a choice to begin, long before anyone feels ready. Doubt shows
                up early, and we plan for it, because it&apos;s part of the process
                and doesn&apos;t mean anything is wrong.
              </p>

              <p>
                Then the first real win lands on your own work, and things click.
                After that comes the messy middle, where progress loops back on
                itself and feels uneven. That&apos;s where coaching matters most,
                and it&apos;s where most teams quietly stall when they go it alone.
              </p>

              <p>
                Stick with it and the roots take hold. Small wins compound into
                momentum, and that momentum turns into time and value you can
                actually measure.
              </p>
            </div>

            <div className="pt-6 sm:pt-8">
              <button
                type="button"
                onClick={() => onOpenAssessment()}
                className="
                  inline-flex
                  items-center
                  gap-2.5
                  px-6
                  sm:px-7
                  py-3.5
                  sm:py-4
                  rounded-xl
                  bg-[#f8c51c]
                  hover:bg-[#e6b312]
                  text-[#0c2940]
                  font-bold
                  text-sm
                  sm:text-base
                  transition-all
                  shadow-lg
                  hover:shadow-[#f8c51c]/30
                  cursor-pointer
                  hover:translate-x-0.5
                "
              >
                <span>Where is your team on the path right now?</span>
                <ArrowRight className="w-4 h-4 text-[#0c2940]" />
              </button>
            </div>
          </div>

          {/* RIGHT COLUMN: INFOGRAPHIC CARD */}
          <div className="lg:col-span-7">
            <div
              className="
                relative
                w-full
                aspect-[16/10]
                min-h-[380px]
                sm:min-h-[460px]
                rounded-[2rem]
                border
                border-white/20
                overflow-hidden
                bg-[#020b14]
                shadow-2xl
              "
            >
              {/* Background generated artwork */}
              <img
                src={growthBgImage}
                alt="Delayed gratification trajectory illustration"
                className="absolute inset-0 w-full h-full object-cover opacity-90"
              />

              {/* Dark subtle overlay for contrast */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#00101F]/80 via-transparent to-[#00101F]/50 pointer-events-none" />

              {/* Top-left title */}
              <div className="absolute top-6 left-6 sm:top-8 sm:left-8 z-10 pointer-events-none">
                <span className="font-montserrat text-sm sm:text-base font-extrabold tracking-[0.14em] text-white uppercase drop-shadow-md">
                  DELAYED GRATIFICATION
                </span>
              </div>

              {/* Stage markers and tooltips */}
              {STAGES.map((stage) => {
                const isHovered = activeStage === stage.id;
                return (
                  <div
                    key={stage.id}
                    style={{ left: stage.x, top: stage.y }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 z-20 group"
                  >
                    <button
                      type="button"
                      onClick={() => onOpenAssessment(stage.name)}
                      onMouseEnter={() => setActiveStage(stage.id)}
                      onMouseLeave={() => setActiveStage(null)}
                      className="
                        relative
                        flex flex-col items-center
                        cursor-pointer
                        focus:outline-none
                      "
                      aria-label={`View stage: ${stage.name}`}
                    >
                      {/* Label badge above or next to node */}
                      <span
                        className={`
                          text-[10px] sm:text-xs font-montserrat font-bold whitespace-nowrap
                          mb-1 transition-all duration-200 drop-shadow-md px-2 py-0.5 rounded-full
                          ${
                            isHovered
                              ? 'bg-[#f8c51c] text-[#0c2940] scale-105 shadow-lg'
                              : 'text-white/95 bg-black/40 backdrop-blur-sm'
                          }
                        `}
                      >
                        {stage.name}
                      </span>

                      {/* Glowing node point */}
                      <span className="relative flex h-4 w-4 sm:h-5 sm:w-5 items-center justify-center">
                        <span
                          className={`
                            relative inline-flex rounded-full h-2.5 w-2.5 sm:h-3 sm:w-3 border-2 border-white
                            ${stage.id === 'momentum' ? 'bg-[#f8c51c]' : 'bg-[#39918d]'}
                          `}
                        />
                      </span>
                    </button>

                    {/* Popover on hover */}
                    {isHovered && (
                      <div className="absolute bottom-full mb-3 left-1/2 -translate-x-1/2 w-48 sm:w-56 p-2.5 bg-slate-900/95 border border-[#39918d] rounded-xl text-left shadow-2xl z-30 pointer-events-none">
                        <div className="text-[#f8c51c] text-[11px] font-bold mb-1">
                          <span>Stage {stage.name}</span>
                        </div>
                        <p className="text-[11px] text-slate-300 leading-snug">
                          {stage.description}
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
