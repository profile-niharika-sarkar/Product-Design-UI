'use client';

import React from 'react';
import { ChevronDown } from 'lucide-react';
import heroBgImage from 'Public/Home-Cover.png';

export const Hero: React.FC = () => {
  const scrollToContent = () => {
    const el = document.getElementById('meet-columbus');
    if (el) {
      el.scrollIntoView({
        behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches
          ? 'auto'
          : 'smooth',
        block: 'start',
      });
    }
  };

  return (
    <section
      id="hero"
      aria-labelledby="hero-heading"
      className="
        relative isolate
        w-full
        min-h-[640px]
        lg:min-h-[100svh]
        overflow-hidden
        bg-[#00101F]
        text-white
        flex flex-col justify-between
      "
    >
      {/* BACKGROUND IMAGE - TREE ON HORIZON */}
      <div
        aria-hidden="true"
        className="
          absolute inset-0 z-[-2]
          bg-cover bg-no-repeat
          bg-[position:74%_center]
          md:bg-[position:68%_center]
          lg:bg-[position:center_center]
        "
        style={{
          backgroundImage: `url(${heroBgImage})`,
        }}
      />

      {/* DARK GRADIENT OVERLAY */}
      <div
        aria-hidden="true"
        className="
          absolute inset-0 z-[-1]
          bg-gradient-to-r
          from-[#00101F]/90
          via-[#00101F]/60
          to-transparent
          pointer-events-none
        "
      />

      {/* TOP PADDING SPACER */}
      <div className="h-10 sm:h-16" />

      {/* HERO CONTAINER - EXACTLY MATCHES 1420px AND px-4 sm:px-6 lg:px-8 */}
      <div className="relative w-full max-w-[1420px] mx-auto px-4 sm:px-6 lg:px-8 my-auto z-10">
        {/* HERO CONTENT */}
        <div className="w-full max-w-[1020px]">
          <h1
            id="hero-heading"
            className="
              m-0
              font-extrabold
              tracking-[-0.035em]
              leading-[1.1]
              break-words
            "
          >
            {/* PRIMARY HEADING */}
            <span
              className="
                block
                max-w-full
                font-inter
                text-[clamp(2.25rem,4.2vw,4.375rem)]
                font-extrabold
                leading-[1.08]
                tracking-[-0.035em]
                text-white
              "
            >
              Stop Implementing AI Tools.
            </span>

            {/* GRADIENT HEADING */}
            <span
              className="
                mt-2 sm:mt-3
                block
                max-w-[950px]
                font-inter
                text-[clamp(1.75rem,3.1vw,3.25rem)]
                font-extrabold
                leading-[1.12]
                tracking-[-0.025em]
                bg-gradient-to-r
                from-[#C57B4B]
                via-[#D98D4A]
                to-[#F8C51C]
                bg-clip-text
                text-transparent
              "
            >
              Start Architecting Human Performance
            </span>
          </h1>

          {/* DESCRIPTION */}
          <p
            className="
              mt-6 sm:mt-8
              max-w-[620px]
              text-base sm:text-lg lg:text-xl
              leading-[1.6]
              font-roboto
              font-normal
              tracking-normal
              text-slate-100/90
            "
          >
            Tell us what you&apos;re working through, and our team will follow up personally.
          </p>
        </div>
      </div>

      {/* BOTTOM CONTROLS ROW - ONLY CENTERED SCROLL INDICATOR (COLUMBUS & N BUTTON REMOVED) */}
      <div className="relative z-20 w-full max-w-[1420px] mx-auto px-4 sm:px-6 lg:px-8 pb-8 sm:pb-10 flex items-center justify-center">
        <button
          type="button"
          onClick={scrollToContent}
          aria-label="Scroll to latest updates"
          className="
            group
            flex
            flex-col
            items-center
            justify-center
            gap-2
            cursor-pointer
            focus-visible:outline-none
            focus-visible:ring-2
            focus-visible:ring-[#F8C51C]
          "
        >
          <span
            className="
              whitespace-nowrap
              text-[10px] sm:text-[11px]
              font-medium
              tracking-[0.2em]
              text-white/80
              transition-colors
              group-hover:text-[#F8C51C]
            "
          >
            SCROLL DOWN
          </span>

          <span
            className="
              flex
              h-9 w-9 sm:h-10 sm:w-10
              items-center
              justify-center
              rounded-full
              border
              border-white/50
              transition-all
              group-hover:border-[#F8C51C]
              group-hover:scale-105
              bg-white/5
            "
          >
            <ChevronDown
              aria-hidden="true"
              className="
                h-4 w-4 sm:h-5 sm:w-5
                text-white
                transition-transform
                group-hover:translate-y-0.5
                group-hover:text-[#F8C51C]
              "
            />
          </span>
        </button>
      </div>
    </section>
  );
};
