import React, { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Krista',
    cohort: 'Sep 2026 Live cohort',
    role: 'Instructional Designer',
    date: 'Oct 16, 2026',
    quote:
      'This course moves past basic prompt engineering into a deeper understanding of how AI works, its capabilities, and ethical considerations.',
  },
  {
    name: 'Melinda',
    cohort: 'Sep 2026 Live cohort',
    role: 'Learning Experience Designer',
    organization: 'Trimark Associates',
    date: 'Oct 16, 2026',
    quote:
      'This course had immediate application in my work. I will use this information and the skills I practiced everyday as I will be tasked with generating AI projects and training at my company.',
  },
  {
    name: 'Melinda Johnson',
    cohort: 'Cohort 3',
    quote:
      'Hi all! Yesterday our CTO (the C level we report to) joined our L&D team strategy meeting and one of his priorities for our team is to track every AI initiative. Exactly what we are doing in this cohort. We do not currently have AI initiatives, but it will be our team’s responsibility to design and track them when we do. Thanks Paige and Dr Mike! Perfect timing.',
  },
  {
    name: 'Leah Otsig',
    role: 'Regional Program Coordinator, Corporate (Master) Trainer and Instructional Designer',
    organization: 'The Institute of Aging and Lifelong Health',
    quote:
      'This cohort is of HUGE value from a work perspective. I would take this program again without even thinking twice. My department was spending 14 days and 40+ hours building a single course manually. Using only tools my university already approved, I rebuilt the process from scratch. The result: 64% reduction in time, 80% reduction in labor, 70% faster development, 75% fewer revision cycles, and $0 in new tools purchased. I’m now building a proposal to scale the process across my team.',
  },
  {
    name: 'Aurilis Sanchez',
    role: 'Instructional Designer & Facilitator',
    quote:
      'Are you kidding me? In less than a minute I had a whole step-by-step solution. I’m not a PowerBI expert, I just manage one. Every time a formula broke, I spent 5+ hours debugging something I couldn’t fully understand. I spent less than 2 hours building an AI assistant using the framework taught in the course. The first time I used it, a problem that used to take 5 hours was solved in under 60 seconds. I called it an out-of-body experience.',
  },
  {
    name: 'Teresa Waggoner',
    role: 'Instructional Designer & Developer',
    quote:
      'I My pain point was healed. I build custom scenario-based learning for clients. It used to take 10 to 80 hours per project. I ran my prompt across three AI tools, compared the outputs against my own quality standards, and went from framework to finished output in 3.5 hours. Generation time per tool: under 7 minutes. I left with a tool selection matrix, a universal stress test prompt, and a replicable workflow I can use across every future client!',
  },
  {
    name: 'Jennifer Ormond',
    role: 'Senior Instructional Designer',
    organization: 'Percpeta',
    quote:
      'I learned so much in Part 1! I mean, it has changed the way I approach these tools already. I came into it thinking I knew what I was doing , and now looking back at where I was just 6 weeks ago, I was a child. I can’t wait for Part 2!',
  },
];

export const Testimonials: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [slideDirection, setSlideDirection] = useState<1 | -1>(1);

  useEffect(() => {
    const intervalId = window.setInterval(() => {
      setSlideDirection(1);
      setActiveIndex((index) => (index + 1) % testimonials.length);
    }, 1500);

    return () => window.clearInterval(intervalId);
  }, []);

  const showPrevious = () => {
    setSlideDirection(-1);
    setActiveIndex((index) => (index - 1 + testimonials.length) % testimonials.length);
  };

  const showNext = () => {
    setSlideDirection(1);
    setActiveIndex((index) => (index + 1) % testimonials.length);
  };

  const activeTestimonial = testimonials[activeIndex];

  return (
    <section
      aria-label="Client testimonials"
      aria-roledescription="carousel"
      className="w-full bg-[#f7f8f6] px-4 py-12 text-[#0c2940] sm:px-6 sm:py-16 lg:px-8"
    >
      <div className="mx-auto w-full max-w-[1420px]">
        <div className="mb-6 flex items-center justify-between gap-4">
          <div>
            <p className="font-montserrat text-xs font-bold uppercase tracking-[0.2em] text-[#39918d]">
              Client stories
            </p>
            <h2 className="mt-2 font-montserrat text-xl font-bold sm:text-2xl">
              Real perspectives. Lasting progress.
            </h2>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <button
              type="button"
              onClick={showPrevious}
              aria-label="Previous testimonial"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-[#0c2940]/20 transition-colors hover:border-[#39918d] hover:text-[#39918d] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#39918d]"
            >
              <ChevronLeft aria-hidden="true" className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={showNext}
              aria-label="Next testimonial"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-[#0c2940]/20 transition-colors hover:border-[#39918d] hover:text-[#39918d] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#39918d]"
            >
              <ChevronRight aria-hidden="true" className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div
          aria-live="off"
          aria-atomic="true"
          aria-roledescription="slide"
          className="min-h-[580px] overflow-hidden rounded-2xl border border-[#0c2940]/10 bg-white p-6 shadow-sm sm:min-h-[460px] sm:p-8 lg:min-h-[380px]"
        >
          <div
            key={activeIndex}
            className={`flex w-full items-start gap-4 sm:gap-6 ${
              slideDirection > 0 ? 'testimonial-slide-right' : 'testimonial-slide-left'
            }`}
          >
            <Quote aria-hidden="true" className="mt-1 h-7 w-7 shrink-0 text-[#39918d] sm:h-9 sm:w-9" />
            <div className="flex min-w-0 flex-1 flex-col">
              <blockquote className="text-base leading-relaxed text-[#0c2940] sm:text-lg lg:text-xl">
                “{activeTestimonial.quote}”
              </blockquote>
              <div className="mt-6 border-t border-[#0c2940]/10 pt-5">
                <p className="font-montserrat text-base font-bold">{activeTestimonial.name}</p>
                <p className="mt-1 font-roboto text-sm leading-relaxed text-slate-600">
                  {activeTestimonial.role}
                  {activeTestimonial.organization && ` · ${activeTestimonial.organization}`}
                </p>
                {(activeTestimonial.cohort || activeTestimonial.date) && (
                  <p className="mt-2 font-roboto text-xs text-slate-500">
                    {[activeTestimonial.cohort, activeTestimonial.date].filter(Boolean).join(' · ')}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-5 flex justify-center gap-2" aria-label="Choose a testimonial">
          {testimonials.map((testimonial, index) => (
            <button
              key={testimonial.name}
              type="button"
              onClick={() => {
                setSlideDirection(index >= activeIndex ? 1 : -1);
                setActiveIndex(index);
              }}
              aria-label={`Show testimonial ${index + 1} from ${testimonial.name}`}
              aria-current={index === activeIndex ? 'true' : undefined}
              className={`h-2.5 rounded-full transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#39918d] ${
                index === activeIndex ? 'w-7 bg-[#39918d]' : 'w-2.5 bg-[#0c2940]/20 hover:bg-[#39918d]/60'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
