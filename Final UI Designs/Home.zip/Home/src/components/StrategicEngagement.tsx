'use client';

import React from 'react';
import { User, Users, Building2 } from 'lucide-react';

export const StrategicEngagement: React.FC = () => {
  return (
    <section
      id="tailored-engagement"
      className="
        w-full
        home-section
        bg-white
        px-4
        sm:px-6
        lg:px-8
      "
    >
      <div className="w-full max-w-[1420px] mx-auto">

        {/* Section Heading */}
        <div className="home-section-head">
          <h2 className="t-h2 text-[#0c2940]">
            Already Know What You Need? Explore Directly.
          </h2>
        </div>

        {/* 3 Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">

          {/* CARD 1 — BUILD YOUR OWN AI FLUENCY */}
          <div
            id="Build-Your-Own-AI-Fluency"
            className="
              bg-[#3f6d67]
              rounded-2xl
              p-7
              lg:p-8
              border
              border-[#3f6d67]
              shadow-sm
              hover:shadow-xl
              hover:scale-[1.01]
              transition-all
              duration-300
              relative
              min-h-[380px]
            "
          >
            <div>
              <div className="flex items-center justify-end mb-6">
                <div className="p-2.5 bg-white/10 text-white rounded-full border border-white/30">
                  <User className="w-5 h-5 text-white" />
                </div>
              </div>

              <h3 className="font-montserrat font-bold text-xl sm:text-2xl text-white mb-3 tracking-tight">
                Build Your Own AI Fluency
              </h3>

              <p className="font-roboto text-sm sm:text-base text-white/95 leading-relaxed mb-8">
                A structured program for individual professionals — practical
                skills, real frameworks, built for sustainable professional
                leverage.
              </p>
            </div>

          </div>

          {/* CARD 2 — STRATEGIC PARTNER FOR EXECUTIVES */}
          <div
            id="for-leaders"
            className="
              bg-[#39918d]
              rounded-2xl
              p-7
              lg:p-8
              border
              border-[#39918d]
              shadow-md
              hover:shadow-xl
              hover:scale-[1.01]
              transition-all
              duration-300
              relative
              min-h-[380px]
            "
          >
            <div>
              <div className="flex items-center justify-end mb-6">
                <div className="p-2.5 bg-white/10 text-white rounded-full border border-white/30">
                  <Users className="w-5 h-5 text-white" />
                </div>
              </div>

              <h3 className="font-montserrat font-bold text-xl sm:text-2xl text-white mb-3 tracking-tight">
                A Strategic Partner for Executives
              </h3>

              <p className="font-roboto text-sm sm:text-base text-white/95 leading-relaxed mb-8">
                A private, one-on-one engagement for leaders who need to build
                an AI strategy they can execute with confidence.
              </p>
            </div>

          </div>

          {/* CARD 3 — ORGANIZATIONS */}
          <div
            id="for-organizations"
            className="
              bg-[#c57b4b]
              rounded-2xl
              p-7
              lg:p-8
              border
              border-[#c57b4b]
              shadow-sm
              hover:shadow-xl
              hover:scale-[1.01]
              transition-all
              duration-300
              relative
              min-h-[380px]
            "
          >
            <div>
              <div className="flex items-center justify-end mb-6">
                <div className="p-2.5 bg-white/10 text-white rounded-full border border-white/30">
                  <Building2 className="w-5 h-5 text-white" />
                </div>
              </div>

              <h3 className="font-montserrat font-bold text-xl sm:text-2xl text-white mb-3 tracking-tight">
                Bring AI Fluency to Your Team
              </h3>

              <p className="font-roboto text-sm sm:text-base text-white/95 leading-relaxed mb-8">
                Training, learning architecture, and community workshops built
                for organizations who want to roll out AI at scale.
              </p>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
