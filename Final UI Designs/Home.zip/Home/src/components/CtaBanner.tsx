'use client';

import React from 'react';
import { Calendar, ArrowRight } from 'lucide-react';

interface CtaBannerProps {
  onOpenBooking: () => void;
}

export const CtaBanner: React.FC<CtaBannerProps> = ({ onOpenBooking }) => {
  return (
    <section
      className="
        w-full
        bg-white
        py-14
        sm:py-18
        lg:py-22
        px-4
        sm:px-6
        lg:px-8
      "
    >
      <div className="w-full max-w-[1420px] mx-auto">
        <div
          className="
            relative
            w-full
            bg-[#0c2940]
            rounded-[2rem]
            px-6
            sm:px-12
            lg:px-16
            py-14
            sm:py-16
            lg:py-20
            flex
            flex-col
            items-center
            justify-center
            text-center
            text-white
            overflow-hidden
            border
            border-[#39918d]/30
            shadow-2xl
            starfield-bg
          "
        >
          {/* Subtle constellation overlay lines */}
          <div className="absolute inset-0 pointer-events-none opacity-25">
            <svg
              className="w-full h-full"
              xmlns="http://www.w3.org/2000/svg"
              preserveAspectRatio="none"
            >
              <line
                x1="8%"
                y1="25%"
                x2="35%"
                y2="55%"
                stroke="#39918d"
                strokeWidth="0.75"
                strokeDasharray="4 4"
              />
              <line
                x1="35%"
                y1="55%"
                x2="65%"
                y2="35%"
                stroke="#c57b4b"
                strokeWidth="0.75"
              />
              <line
                x1="65%"
                y1="35%"
                x2="90%"
                y2="45%"
                stroke="#f8c51c"
                strokeWidth="0.5"
                strokeDasharray="3 3"
              />

              <circle cx="8%" cy="25%" r="2.5" fill="#f8c51c" />
              <circle cx="35%" cy="55%" r="3" fill="#39918d" />
              <circle cx="65%" cy="35%" r="2.5" fill="#ffffff" />
              <circle cx="90%" cy="45%" r="2" fill="#c57b4b" />
            </svg>
          </div>

          {/* Main Content */}
          <div className="relative z-10 w-full max-w-3xl mx-auto flex flex-col items-center">
            {/* Heading */}
            <h2
              className="
                font-montserrat
                text-white
                text-2xl
                sm:text-3xl
                lg:text-[2.5rem]
                font-bold
                leading-tight
                tracking-tight
                mb-3
              "
            >
              Not Sure Which Path Is Right for You?
            </h2>

            {/* Supporting Text */}
            <p
              className="
                text-slate-200
                text-base
                sm:text-lg
                lg:text-xl
                font-roboto
                leading-relaxed
                mb-8
              "
            >
              Talk it through with us directly.
            </p>

            {/* CTA Button */}
            <button
              type="button"
              onClick={onOpenBooking}
              className="
                inline-flex
                items-center
                justify-center
                gap-3
                px-8
                sm:px-9
                py-3.5
                sm:py-4
                rounded-xl
                text-xs
                sm:text-sm
                font-montserrat
                font-bold
                uppercase
                tracking-wider
                text-white
                bg-[#39918d]
                hover:bg-[#337e7a]
                transition-all
                duration-300
                shadow-xl
                hover:shadow-[#39918d]/30
                cursor-pointer
                group
                border
                border-white/20
              "
            >
              <Calendar
                className="
                  w-4
                  h-4
                  sm:w-5
                  sm:h-5
                  text-[#f8c51c]
                "
              />

              <span>BOOK A DISCOVERY CALL</span>

              <ArrowRight
                className="
                  w-4
                  h-4
                  text-white
                  group-hover:translate-x-1
                  transition-transform
                "
              />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
