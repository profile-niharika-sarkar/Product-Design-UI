'use client';

import React, { useState } from 'react';
import { X, Send, Sparkles, MessageSquare, Bot, User, ArrowRight, Check } from 'lucide-react';

interface ColumbusModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenBooking: () => void;
}

interface Message {
  sender: 'columbus' | 'user';
  text: string;
}

const QUICK_PROMPTS = [
  "What is The Bradbury Group's core approach?",
  "How does Columbus assist without automated sales pitches?",
  "Tell me about executive strategy partnerships",
  "How do you train enterprise teams on AI fluency?",
];

export const ColumbusModal: React.FC<ColumbusModalProps> = ({
  isOpen,
  onClose,
  onOpenBooking,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'columbus',
      text: "Hello! I'm Columbus. I'm here to listen to what you're working through and help clarify your path. Our leadership team reviews every inquiry personally — no automated sales bots, no generic pitches.",
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  if (!isOpen) return null;

  const handleSend = (textToSend?: string) => {
    const text = textToSend || input.trim();
    if (!text) return;

    const userMsg: Message = { sender: 'user', text };
    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsTyping(true);

    setTimeout(() => {
      let reply = "Thank you for sharing. We focus on architecting human performance rather than just implementing disconnected AI tools.";
      const lower = text.toLowerCase();
      if (lower.includes('approach') || lower.includes('different') || lower.includes('core')) {
        reply = "Our core approach is built on structure, not screenshots. Instead of teaching which buttons to click in transient tools, we build cognitive frameworks for how humans think alongside AI. We start with how adults actually learn, navigate the messy middle, and reach compounding momentum.";
      } else if (lower.includes('columbus') || lower.includes('work') || lower.includes('sales')) {
        reply = "I collect the context of your challenges — whether you are an individual wanting professional leverage, an executive needing strategy, or an enterprise rolling out fluency. I synthesize your notes so our human partners arrive at your consultation fully prepared.";
      } else if (lower.includes('executive') || lower.includes('leader') || lower.includes('solomon')) {
        reply = "For executives, we offer 'The Solomon Engine': a private, one-on-one advisory relationship. We help leaders build an executable AI roadmap, audit internal readiness, and lead their workforce through technological shifts with confidence.";
      } else if (lower.includes('team') || lower.includes('enterprise') || lower.includes('organization')) {
        reply = "For organizations, we architect fluency at scale. That includes custom cohort curriculums, learning architecture, and internal champions communities that stick beyond initial pilot hype.";
      } else {
        reply = "That's exactly what we help organizations and leaders work through. Every team experiences the 'messy middle' before momentum builds. Would you like to schedule a 30-minute discovery call to talk it through directly?";
      }

      setMessages((prev) => [...prev, { sender: 'columbus', text: reply }]);
      setIsTyping(false);
    }, 600);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-[#0c2940] border border-[#39918d]/50 rounded-2xl w-full max-w-xl h-[620px] max-h-[90vh] flex flex-col overflow-hidden shadow-2xl text-white">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#39918d]/30 bg-[#00101F]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#39918d]/20 border border-[#39918d]/40 flex items-center justify-center text-[#39918d]">
              <Bot className="w-5 h-5 text-[#39918d]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-montserrat font-bold text-base text-white">Columbus</h3>
                <span className="text-[10px] font-mono uppercase bg-[#3f6d67] px-2 py-0.5 rounded-full text-white/90">
                  AI Guide
                </span>
              </div>
              <p className="text-xs text-slate-300 font-roboto">
                The Bradbury Group Strategic Assistant
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close chat"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message history */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 font-roboto text-sm">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex gap-3 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'columbus' && (
                <div className="w-7 h-7 rounded-full bg-[#39918d]/30 flex items-center justify-center shrink-0 text-[#39918d] mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              <div
                className={`max-w-[82%] rounded-2xl p-3.5 leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-[#39918d] text-white rounded-tr-none'
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none'
                }`}
              >
                {m.text}
              </div>
              {m.sender === 'user' && (
                <div className="w-7 h-7 rounded-full bg-slate-800 flex items-center justify-center shrink-0 text-slate-300 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-2 items-center text-xs text-slate-400 pl-10">
              <span className="inline-block w-2 h-2 rounded-full bg-[#39918d] animate-bounce" />
              <span className="inline-block w-2 h-2 rounded-full bg-[#39918d] animate-bounce [animation-delay:0.2s]" />
              <span className="inline-block w-2 h-2 rounded-full bg-[#39918d] animate-bounce [animation-delay:0.4s]" />
            </div>
          )}
        </div>

        {/* Quick prompt suggestions */}
        <div className="px-4 py-2 border-t border-slate-800/80 bg-slate-950/60 overflow-x-auto flex gap-2 no-scrollbar">
          {QUICK_PROMPTS.map((prompt, i) => (
            <button
              key={i}
              type="button"
              onClick={() => handleSend(prompt)}
              className="text-[11px] whitespace-nowrap bg-white/5 hover:bg-white/10 border border-white/10 rounded-full px-3 py-1 text-slate-300 transition-colors cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input box and CTA */}
        <div className="p-4 bg-[#00101F] border-t border-[#39918d]/30 flex flex-col gap-3">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Tell Columbus what you're working through..."
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-[#39918d]"
            />
            <button
              type="submit"
              disabled={!input.trim()}
              className="p-2.5 bg-[#39918d] hover:bg-[#337e7a] disabled:opacity-40 text-white rounded-xl transition-all cursor-pointer"
              aria-label="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>Ready for a live conversation?</span>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenBooking();
              }}
              className="text-[#f8c51c] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
            >
              <span>Book Discovery Call</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
