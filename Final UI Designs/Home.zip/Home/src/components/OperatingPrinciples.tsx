'use client';

import React from 'react';
import { LayoutGrid, Users2, ShieldCheck } from 'lucide-react';

export const OperatingPrinciples: React.FC = () => {
  return (
    <section
      id="principles"
      className="
        w-full
        home-section
        bg-white
        px-4
        sm:px-6
        lg:px-8
      "
    >
      <div className="w-full max-w-[1420px] mx-auto">

        {/* Section Heading */}
        <div className="home-section-head">
          <h2 className="t-h2 text-[#0c2940]">
            How We&apos;re Different
          </h2>
        </div>

        {/* 3 Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">

          {/* CARD 1 */}
          <div
            className="
              rounded-2xl
              p-7
              sm:p-8
              border
              border-white/15
              shadow-sm
              hover:shadow-lg
              hover:scale-[1.01]
              transition-all
              duration-300
              flex
              flex-col
              justify-between
              min-h-[290px]
              relative
              overflow-hidden
            "
            style={{
              backgroundColor: '#3f6d67',
              backgroundImage: `radial-gradient(rgba(255, 255, 255, 0.12) 1px, transparent 1px)`,
              backgroundSize: '24px 24px',
            }}
          >
            <div>
              {/* Icon */}
              <div
                className="
                  w-11
                  h-11
                  rounded-xl
                  bg-white/10
                  text-white
                  flex
                  items-center
                  justify-center
                  mb-6
                  border
                  border-white/20
                "
              >
                <LayoutGrid className="w-5 h-5 text-white" />
              </div>

              {/* Heading */}
              <h3 className="font-montserrat font-bold text-xl sm:text-2xl text-white mb-3 tracking-tight">
                Built on structure, not screenshots.
              </h3>

              {/* Description */}
              <p className="font-roboto text-sm sm:text-base text-white/90 leading-relaxed">
                We explore how to think with AI, not which buttons to click.
              </p>
            </div>
          </div>

          {/* CARD 2 */}
          <div
            className="
              rounded-2xl
              p-7
              sm:p-8
              border
              border-white/15
              shadow-sm
              hover:shadow-lg
              hover:scale-[1.01]
              transition-all
              duration-300
              flex
              flex-col
              justify-between
              min-h-[290px]
              relative
              overflow-hidden
            "
            style={{
              backgroundColor: '#39918d',
              backgroundImage: `radial-gradient(rgba(255, 255, 255, 0.12) 1px, transparent 1px)`,
              backgroundSize: '24px 24px',
            }}
          >
            <div>
              {/* Icon */}
              <div
                className="
                  w-11
                  h-11
                  rounded-xl
                  bg-white/10
                  text-white
                  flex
                  items-center
                  justify-center
                  mb-6
                  border
                  border-white/20
                "
              >
                <Users2 className="w-5 h-5 text-white" />
              </div>

              {/* Heading */}
              <h3 className="font-montserrat font-bold text-xl sm:text-2xl text-white mb-3 tracking-tight">
                People-first.
              </h3>

              {/* Description */}
              <p className="font-roboto text-sm sm:text-base text-white/90 leading-relaxed">
                Every learning journey starts with how people actually learn
                and adopt new skills — not just the tools themselves.
              </p>
            </div>
          </div>

          {/* CARD 3 */}
          <div
            className="
              rounded-2xl
              p-7
              sm:p-8
              border
              border-white/15
              shadow-sm
              hover:shadow-lg
              hover:scale-[1.01]
              transition-all
              duration-300
              flex
              flex-col
              justify-between
              min-h-[290px]
              relative
              overflow-hidden
            "
            style={{
              backgroundColor: '#c57b4b',
              backgroundImage: `radial-gradient(rgba(255, 255, 255, 0.12) 1px, transparent 1px)`,
              backgroundSize: '24px 24px',
            }}
          >
            <div>
              {/* Icon */}
              <div
                className="
                  w-11
                  h-11
                  rounded-xl
                  bg-white/10
                  text-white
                  flex
                  items-center
                  justify-center
                  mb-6
                  border
                  border-white/20
                "
              >
                <ShieldCheck className="w-5 h-5 text-white" />
              </div>

              {/* Heading */}
              <h3 className="font-montserrat font-bold text-xl sm:text-2xl text-white mb-3 tracking-tight">
                Proven, not promised.
              </h3>

              {/* Description */}
              <p className="font-roboto text-sm sm:text-base text-white/90 leading-relaxed">
                Every framework we use has been vetted and tested with real
                clients.
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
