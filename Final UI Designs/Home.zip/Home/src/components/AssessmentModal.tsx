'use client';

import React, { useState } from 'react';
import { X, ArrowRight, CheckCircle2, AlertCircle, Compass, Sparkles } from 'lucide-react';

interface AssessmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialStage?: string;
  onOpenBooking: () => void;
}

const STAGE_DETAILS = [
  {
    title: 'Choose to Start',
    subtitle: 'The Single Seed',
    badgeColor: 'bg-emerald-900/60 border-emerald-500/40 text-emerald-300',
    description:
      'Long before anyone feels ready. You are exploring what AI actually means for your specific domain, cutting through vendor noise, and deciding to take the first concrete step.',
    risk: 'Analysis paralysis and waiting for the "perfect tool" to emerge.',
    prescription:
      'Begin with high-leverage personal use-cases. Establish psychological safety and a consistent testing cadence.',
  },
  {
    title: 'Emotions Surface',
    subtitle: 'Early Friction & Doubt',
    badgeColor: 'bg-amber-900/60 border-amber-500/40 text-amber-300',
    description:
      'Doubt shows up early. People wonder if AI will replace them, worry about making mistakes, or feel overwhelmed by rapid model shifts. This is normal and expected.',
    risk: 'Quiet disengagement or treating AI as a passing executive fad.',
    prescription:
      'Frame AI as a thinking partner and cognitive multiplier. Focus on human workflows rather than tech specifications.',
  },
  {
    title: 'The Aha Moment',
    subtitle: 'The First Real Win',
    badgeColor: 'bg-cyan-900/60 border-cyan-500/40 text-cyan-300',
    description:
      'The first real breakthrough lands directly on your daily work. A complex analysis that used to take days happens in an hour. The value becomes visceral.',
    risk: 'Treating the win as an isolated trick without building systemic habits.',
    prescription:
      'Codify the prompt architecture and reasoning steps into repeatable frameworks for the wider organization.',
  },
  {
    title: 'The Messy Middle',
    subtitle: 'Uneven Progress & Loops',
    badgeColor: 'bg-rose-900/60 border-rose-500/40 text-rose-300',
    description:
      'Progress loops back on itself. Some workflows break, context windows get messy, and teams experience uneven adoption. This is where most unguided teams stall.',
    risk: 'Dropping back into legacy manual habits due to friction.',
    prescription:
      'Targeted coaching and structured learning architecture. This is our primary focus with enterprise cohorts and leaders.',
  },
  {
    title: 'Momentum Builds',
    subtitle: 'Compounding Enterprise Value',
    badgeColor: 'bg-yellow-900/60 border-yellow-500/40 text-yellow-300',
    description:
      'Roots have taken hold. Teams instinctively architect multi-agent workflows, synthesis pipelines, and high-velocity deliverables. Time and ROI become clearly measurable.',
    risk: 'Siloed gains that fail to influence broader company culture.',
    prescription:
      'Institutionalize internal AI champions networks and continuous strategic advisory.',
  },
];

export const AssessmentModal: React.FC<AssessmentModalProps> = ({
  isOpen,
  onClose,
  initialStage,
  onOpenBooking,
}) => {
  const [selectedIdx, setSelectedIdx] = useState<number>(() => {
    if (!initialStage) return 0;
    const found = STAGE_DETAILS.findIndex((s) =>
      s.title.toLowerCase().includes(initialStage.toLowerCase())
    );
    return found !== -1 ? found : 0;
  });

  if (!isOpen) return null;

  const current = STAGE_DETAILS[selectedIdx];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-[#0c2940] border border-[#39918d]/50 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden shadow-2xl text-white flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[#39918d]/30 bg-[#00101F]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-[#39918d]/20 text-[#f8c51c]">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-montserrat font-bold text-lg text-white">
                Human Performance Growth Path
              </h3>
              <p className="text-xs text-slate-300 font-roboto">
                Select where your team is today to see the diagnostic &amp; next step
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Stage Selector Pills */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {STAGE_DETAILS.map((stage, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setSelectedIdx(i)}
                className={`p-2.5 rounded-xl text-left border transition-all text-xs cursor-pointer ${
                  selectedIdx === i
                    ? 'bg-[#39918d] border-white text-white shadow-md'
                    : 'bg-slate-900/80 border-slate-700/80 text-slate-300 hover:border-slate-500'
                }`}
              >
                <div className="font-montserrat font-bold truncate">0{i + 1}</div>
                <div className="font-medium text-[11px] truncate mt-0.5">{stage.title}</div>
              </button>
            ))}
          </div>

          {/* Active Stage Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-[#f8c51c]">
                  Stage 0{selectedIdx + 1}
                </span>
                <h4 className="font-montserrat font-bold text-xl text-white mt-0.5">
                  {current.title}
                </h4>
                <p className="text-xs text-[#39918d] font-medium">{current.subtitle}</p>
              </div>
            </div>

            <p className="text-sm font-roboto text-slate-300 leading-relaxed">
              {current.description}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
                <div className="flex items-center gap-2 text-rose-400 text-xs font-semibold mb-1">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>The Critical Risk</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">{current.risk}</p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-[#39918d]/30">
                <div className="flex items-center gap-2 text-[#f8c51c] text-xs font-semibold mb-1">
                  <Sparkles className="w-4 h-4 shrink-0" />
                  <span>The Architecture Prescription</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{current.prescription}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-6 bg-[#00101F] border-t border-[#39918d]/30 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-slate-400 font-roboto text-center sm:text-left">
            Need guidance navigating the transition to compounding momentum?
          </p>
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenBooking();
            }}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#39918d] hover:bg-[#337e7a] text-white text-xs font-montserrat font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg"
          >
            <span>Discuss With Us</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
