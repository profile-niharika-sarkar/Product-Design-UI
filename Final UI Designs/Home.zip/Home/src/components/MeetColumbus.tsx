'use client';

import React from 'react';
import { ArrowRight } from 'lucide-react';

interface MeetColumbusProps {
  onOpenColumbus: () => void;
}

export const MeetColumbus: React.FC<MeetColumbusProps> = ({ onOpenColumbus }) => {
  return (
    <div id="meet-columbus" className="w-full bg-[#00101F] px-4 sm:px-6 lg:px-8 pt-10 sm:pt-14 pb-8 sm:pb-12">
      <div className="w-full max-w-[1420px] mx-auto">
        <div
          onClick={onOpenColumbus}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              onOpenColumbus();
            }
          }}
          className="
            group
            w-full
            rounded-3xl
            bg-[#3f6d67]
            border
            border-white/15
            shadow-xl
            hover:border-white/30
            hover:shadow-2xl
            hover:brightness-105
            transition-all
            duration-300
            px-6
            sm:px-8
            lg:px-10
            py-7
            sm:py-8
            lg:py-9
            cursor-pointer
            relative
            overflow-hidden
          "
        >
          {/* Subtle gradient sheen on hover */}
          <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/5 to-white/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

          <div className="flex items-center justify-between mb-3">
            <p
              className="
                text-xs
                sm:text-sm
                uppercase
                tracking-[0.18em]
                text-white
                font-bold
                m-0
              "
            >
              <span>MEET COLUMBUS</span>
            </p>

            <span className="text-white/80 group-hover:text-white group-hover:translate-x-1 transition-all text-xs font-semibold flex items-center gap-1.5 hidden sm:inline-flex">
              <span>Ask Columbus</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>

          <h3
            className="
              home-body
              text-base
              sm:text-lg
              lg:text-xl
              font-medium
              text-white
              leading-relaxed
              max-w-none
              m-0
            "
          >
            Columbus is our AI assistant. It&apos;ll ask a few questions about
            what you&apos;re looking for, and our team follows up personally —
            no bots deciding anything, no automated sales pitch. Full
            details on how it works are one click away.
          </h3>
        </div>
      </div>
    </div>
  );
};
