'use client';

import React, { useState } from 'react';
import { X, Calendar, Clock, ShieldCheck } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultPath?: string;
}

interface BookingApiResponse {
  ok?: boolean;
  error?: string;
}

function parseBookingResponse(body: string): BookingApiResponse | null {
  try {
    const parsed: unknown = JSON.parse(body);
    if (typeof parsed !== 'object' || parsed === null) return null;

    const response = parsed as Record<string, unknown>;
    return {
      ok: response.ok === true,
      error: typeof response.error === 'string' ? response.error : undefined,
    };
  } catch {
    return null;
  }
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  defaultPath = 'For Leaders',
}) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [form, setForm] = useState({
    name: '',
    email: '',
    company: '',
    role: 'Executive Leader',
    path: defaultPath,
    notes: '',
  });

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitError('');

    try {
      const response = await fetch('/api/booking', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const result = parseBookingResponse(await response.text());

      if (!response.ok) {
        throw new Error(
          result?.error ||
            `Booking request failed (HTTP ${response.status}). Please try again or contact us directly.`,
        );
      }

      if (!result?.ok) {
        throw new Error(
          'The booking service did not confirm your request. Please try again or contact us directly.',
        );
      }

      window.location.assign(
        'https://calendar.google.com/calendar/u/0/appointments/schedules/AcZssZ02gbI3oOoAkk6FnRZpu6RUQTiAo23ewsroiiCMwZD_Jcf8yRwqAFRAz11Xy9kDhIE10O74E_Yp',
      );
    } catch (error) {
      setSubmitError(
        error instanceof Error
          ? error.message
          : 'We could not submit your request. Please try again.',
      );
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div className="bg-[#0c2940] border border-[#39918d]/50 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl text-white p-6 sm:p-8 relative">
        <div className="flex items-center justify-between pb-4 border-b border-[#39918d]/30 mb-6">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#39918d]/20 text-[#f8c51c]">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-montserrat font-bold text-lg text-white">
                Book Strategic Consultation
              </h3>
              <p className="text-xs text-slate-300 font-roboto flex items-center gap-1.5 mt-0.5">
                <Clock className="w-3.5 h-3.5 text-[#f8c51c]" />
                <span>30-minute private discovery session</span>
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs font-roboto">
            <div className="space-y-1.5">
              <label className="text-slate-300 font-medium">Full Name *</label>
              <input
                required
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. Your Name"
                className="w-full bg-slate-950/80 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-[#39918d] transition-colors"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-slate-300 font-medium">Work Email *</label>
                <input
                  required
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="yourname@enterprise.com"
                  className="w-full bg-slate-950/80 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-[#39918d] transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-medium">Organization / Company</label>
                <input
                  type="text"
                  value={form.company}
                  onChange={(e) => setForm({ ...form, company: e.target.value })}
                  placeholder="Company Name."
                  className="w-full bg-slate-950/80 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-[#39918d] transition-colors"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 font-medium">Primary Focus Path</label>
              <select
                value={form.path}
                onChange={(e) => setForm({ ...form, path: e.target.value })}
                className="w-full bg-slate-950/80 border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:border-[#39918d] transition-colors"
              >
                <option value="For You">For You (Individual Coaching & Agent Workflows)</option>
                <option value="For Leaders">For Leaders (VPs, Department Heads & Strategic AI)</option>
                <option value="For Organizations">For Organizations (Enterprise AI Architecture & Scale)</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 font-medium">Key Objectives / Notes</label>
              <textarea
                rows={3}
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                placeholder="Briefly describe what you're working through or your team's goals..."
                className="w-full bg-slate-950/80 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-[#39918d] resize-none transition-colors"
              />
            </div>

            <div className="flex items-center gap-2 text-[11px] text-slate-400 pt-1">
              <ShieldCheck className="w-4 h-4 text-[#39918d] shrink-0" />
              <span>Strictly confidential. No automated sales pitches or spam.</span>
            </div>

            <div className="pt-2">
              {submitError && (
                <p role="alert" className="mb-3 text-sm text-red-300">
                  {submitError}
                </p>
              )}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 rounded-xl bg-[#39918d] hover:bg-[#337e7a] text-white font-montserrat font-bold uppercase tracking-wider text-xs transition-all shadow-lg hover:shadow-[#39918d]/30 cursor-pointer disabled:cursor-not-allowed disabled:opacity-70"
              >
                {isSubmitting ? 'Submitting request…' : 'Confirm 30-Min Discovery Session'}
              </button>
            </div>
        </form>
      </div>
    </div>
  );
};
